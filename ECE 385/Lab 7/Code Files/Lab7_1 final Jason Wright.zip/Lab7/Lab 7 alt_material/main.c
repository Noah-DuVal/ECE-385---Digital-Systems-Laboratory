

#include <system.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <alt_types.h>
#include "text_mode_vga.h"
#include "test_mode_vga.c"


int main (){


while (1)
{
void textVGATest();
}





}



